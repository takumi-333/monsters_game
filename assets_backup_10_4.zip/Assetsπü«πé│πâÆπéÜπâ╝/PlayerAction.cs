using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class PlayerAction : Action
{
    public PlayerAction(int attacker, int defender, int action_id) : base(attacker, defender, action_id){}

    public void HandleAction(List<MonsterData.Param> enemy_monster_params) {
        enemy_monster_params[defender].hp -= 5;
    }
}
