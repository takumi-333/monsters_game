using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleManager : MonoBehaviour
{
    private double _time;
    private double turn_wait_time = 0;
    GameObject Screen;
    private MonsterData monster_data;

    private List<RawImage> enemy_images = new List<RawImage>();

    // player's monster info
    private int pMonster_id = 0;
    private MonsterData.Param pMonster_param;
    private GameObject status_window;

    // enemy monster info
    private List<MonsterData.Param> enemy_monster_params = new List<MonsterData.Param>();
    private MonsterData.Param monster_param;
    private int num_monster;

    private GameObject command_window;
    private List<GameObject> command_blocks = new List<GameObject>();

    //仮のボタン、これを押すと戦闘開始
    private GameObject start_button;

    private SceneType SceneMode = SceneType.SELECT; 

    // ATTACK時に使用する変数
    private int select_monster;
    private float cursor_blink_rate = 1.0f;
    

    // PROCESS時に使用する変数
    private int scene_step = 0;
    private int action_step = 0;
    private List<int> action_order;
    private List<Action> actions;

    public enum CommandType
    {
        ATTACK = 0,
        ITEM = 1,
        SPECIAL = 2,
        ESCAPE = 3
    }

    public enum SceneType
    {
        SELECT,
        ATTACK,
        ITEM,
        SPECIAL,
        ESCAPE,
        PROCESS,
    }

    public string[] command_block_str = {"attack", "item", "special", "escape"};

    // Start is called before the first frame update
    void Start()
    {
        // command_window = GameObject.Find("CommandWindow").GetComponent<GameObject>();
        command_window = GameObject.Find("CommandWindow");
        start_button = GameObject.Find("GenerateButton");
        monster_data = Resources.Load("monster_data") as MonsterData;

        Screen = GameObject.Find("BackgroundImage");
    }

    // status windowもmonsterのパラメータもセットする関数
    public void SetPlayerMonsters() 
    {
        // set player's monster parameter
        pMonster_param = monster_data.sheets[0].list.Find(monster=> monster.id == pMonster_id);

        // set status window
        GameObject status_window_prefab = Resources.Load<GameObject>("StatusWindow");
        status_window = Instantiate(status_window_prefab);
        status_window.transform.SetParent(Screen.transform);
        Vector3 pos = new Vector3(-250, 150, 0);
        status_window.transform.localPosition = pos;

        status_window.transform.Find("NameText").GetComponent<TextMeshProUGUI>().text = pMonster_param.name_en;
        status_window.transform.Find("HpText").GetComponent<TextMeshProUGUI>().text = $"HP: {pMonster_param.hp}";
        status_window.transform.Find("MpText").GetComponent<TextMeshProUGUI>().text = $"MP: {pMonster_param.mp}";
        status_window.transform.Find("MonsterImage").GetComponent<RawImage>().texture = Resources.Load<Texture2D>(pMonster_param.image_path);
    }

    public void ChooseMonsterByWeight() 
    {
        int total_weight = 0;
        for (int i = 0; i < monster_data.sheets[0].list.Count; i++) {
            total_weight += monster_data.sheets[0].list[i].weight;
        }
        int r = Random.Range(1, total_weight);
        for (int i = 0; i < monster_data.sheets[0].list.Count; i++) {
            if (r < monster_data.sheets[0].list[i].weight) {
                monster_param = monster_data.sheets[0].list[i];
                break;
            }
            r -= monster_data.sheets[0].list[i].weight;
        }
    }

    public int ClickCommandBlock(Vector3 mousePos) 
    {
        GameObject command_prefab = Resources.Load<GameObject>("Command");
        Vector2 command_block_size = command_prefab.GetComponent<RectTransform>().sizeDelta;
        int index = -1;

        foreach(GameObject command_block in command_blocks) {
            index += 1;
            Vector3 relativeMousePos = command_block.transform.InverseTransformPoint(mousePos);
            if ((relativeMousePos.x >= -(command_block_size.x / 2) && relativeMousePos.x <= command_block_size.x / 2) &&
            (relativeMousePos.y >= -(command_block_size.y / 2) && relativeMousePos.y <= command_block_size.y / 2)
            ) {
                return index;
            }
        }

        return -1;
    }

    public void HandleCommandSelect(int command_id)
    {
        // 押されたコマンドブロック以外のブロックを非表示
        for (int i = 0; i < 4; i++) {
            if (i != command_id) {
                command_blocks[i].SetActive(false);
            }
        }

        switch (command_id) {
            case 0:
                SceneMode = SceneType.ATTACK;
                select_monster = 0;
                break;
            case 1:
                SceneMode = SceneType.ITEM;
                break;
            case 2:
                SceneMode = SceneType.SPECIAL;
                break;
            case 3:
                SceneMode = SceneType.ESCAPE;
                break;
            default:
                break;
        }
    }

    // Enemyに対するマウスフォーカスの処理
    public void FocusEnemy(Vector3 mousePos) 
    {
        int index = -1;
        foreach(RawImage enemy_image in enemy_images) {
            index += 1;
            Vector3 relativeMousePos = enemy_image.transform.InverseTransformPoint(mousePos);
            Vector2 size = enemy_image.rectTransform.sizeDelta;
            if ((relativeMousePos.x >= -(size.x / 2) && relativeMousePos.x <= size.x / 2) &&
            (relativeMousePos.y >= -(size.y / 2) && relativeMousePos.y <= size.y / 2)
            ) {
                select_monster = index;
                return;
            }
        }
    }

    public int ClickEnemy(Vector3 mousePos) 
    {
        int index = -1;
        foreach(RawImage enemy_image in enemy_images) {
            index += 1;
            Vector3 relativeMousePos = enemy_image.transform.InverseTransformPoint(mousePos);
            Vector2 size = enemy_image.rectTransform.sizeDelta;
            if ((relativeMousePos.x >= -(size.x / 2) && relativeMousePos.x <= size.x / 2) &&
            (relativeMousePos.y >= -(size.y / 2) && relativeMousePos.y <= size.y / 2)
            ) {
                return index;
            }
        }
        return -1;
    }

    public void StartBattle()
    {
        SetPlayerMonsters();

        // COMMAND BLOCKのセット処理
        GameObject command_prefab = Resources.Load<GameObject>("Command");
        for (int i=0; i < 4; i++) {
            GameObject command_block = Instantiate(command_prefab);
            command_block.transform.SetParent(command_window.transform);
            command_blocks.Add(command_block);
        }
        Vector3[] command_block_pos = {new Vector3(-160, 35, 0), new Vector3(-160, -35, 0),
                                       new Vector3(160, 35, 0), new Vector3(160, -35, 0)};
        

        for (int i = 0; i < 4; i++) {
            command_blocks[i].transform.localPosition = command_block_pos[i];
            command_blocks[i].transform.Find("CommandText").GetComponent<TextMeshProUGUI>().text = command_block_str[i];
        }
        
        // set Monsters
        //無駄な処理多いからforループにしたいね
        num_monster = Random.Range(1,4);

        GameObject enemy_image_prefab = Resources.Load<GameObject>("EnemyImage");
        for (int i = 0; i < num_monster; i++) {
            GameObject enemy_image = Instantiate(enemy_image_prefab);
            enemy_image.transform.SetParent(Screen.transform);
            enemy_images.Add(enemy_image.GetComponent<RawImage>());
        }

        // 配置座標パターン
        // これを計算で出せるようにしないとswitch文が必要になる
        Vector3[] pos_pattern1 = {new Vector3(0,0,0)};
        Vector3[] pos_pattern2 = {new Vector3(-80,0,0), new Vector3(80,0,0)};
        Vector3[] pos_pattern3 = {new Vector3(-120,0,0), new Vector3(0,0,0), new Vector3(120,0,0)};
        Vector3[] pos_pattern4 = {new Vector3(-240,0,0), new Vector3(-80,0,0), new Vector3(80,0,0), new Vector3(240,0,0)};
        switch (num_monster) {
            case 1:
                ChooseMonsterByWeight();
                enemy_monster_params.Add(monster_param);
                enemy_images[0].enabled = true;
                enemy_images[0].texture = Resources.Load<Texture2D> (monster_param.image_path);
                enemy_images[0].transform.localPosition = pos_pattern1[0];
                break;
            case 2:
                for (int i=0; i<2; i++) {
                    ChooseMonsterByWeight();
                    enemy_monster_params.Add(monster_param);
                    enemy_images[i].enabled= true;
                    enemy_images[i].texture = Resources.Load<Texture2D> (monster_param.image_path);
                    enemy_images[i].transform.localPosition = pos_pattern2[i];
                }
                break;
            case 3:
                for (int i=0; i<3; i++) {
                    ChooseMonsterByWeight();
                    enemy_monster_params.Add(monster_param);
                    enemy_images[i].enabled= true;
                    enemy_images[i].texture = Resources.Load<Texture2D> (monster_param.image_path);
                    enemy_images[i].transform.localPosition = pos_pattern3[i];
                }
                break;
            case 4:
                for (int i=0; i<4; i++) {
                    ChooseMonsterByWeight();
                    enemy_monster_params.Add(monster_param);
                    enemy_images[i].enabled= true;
                    enemy_images[i].texture = Resources.Load<Texture2D> (monster_param.image_path);
                    enemy_images[i].transform.localPosition = pos_pattern4[i];
                }
                break;
        }
        Destroy(start_button);
    }

    public List<int> SetActionOrder() {

        //player: num_monster番
        List<int> _action_order = new List<int>();
        _action_order.Add(num_monster);
        for (int i=0; i<num_monster; i++) {
            _action_order.Add(i);
        }
        return _action_order;
    }

    public List<Action> SetActions(int enemy_id) {
        List<Action> _actions = new List<Action>();
        for (int i=0; i<num_monster; i++) {
            EnemyAction enemy_action = new EnemyAction(i, num_monster, 0);
            _actions.Add(enemy_action);
        }
        PlayerAction p_action = new PlayerAction(num_monster, enemy_id, 0);
        _actions.Add(p_action);
        return _actions;
    }

    void Update() 
    {
        turn_wait_time -= Time.deltaTime;
        Vector3 mousePos;
        switch (SceneMode) {
            case SceneType.SELECT:
                if (Input.GetMouseButtonDown(0)) {
                    mousePos = Input.mousePosition;
                    int command_id = ClickCommandBlock(mousePos);
                    if (command_id >= 0) {
                        Debug.Log($"block {command_id} is clicked");
                        HandleCommandSelect(command_id);
                    } else {
                        Debug.Log("どれもクリックされてない");
                    }
                }
                break;
            case SceneType.ATTACK:
                mousePos = Input.mousePosition;

                // 選択されているモンスター以外のカーソルを非表示
                for (int i = 0; i < num_monster; i++) {
                    if (i != select_monster) {
                        enemy_images[i].transform.Find("Cursor").gameObject.SetActive(false);
                    }
                }

                // カーソルの点滅処理
                _time += Time.deltaTime;
                var repeatValue = Mathf.Repeat((float)_time, cursor_blink_rate);
                enemy_images[select_monster].transform.Find("Cursor").gameObject.SetActive(repeatValue >= 0.5f);

                // クリック時の処理
                if (Input.GetMouseButtonDown(0)) {
                    mousePos = Input.mousePosition;
                    // ATTACKをやめるときの処理
                    if (ClickCommandBlock(mousePos) == 0) {

                        // 遷移処理
                        for (int i = 0; i < 4; i++) {
                            command_blocks[i].SetActive(true);
                        }
                        for (int i = 0; i < num_monster; i++) {
                            enemy_images[i].transform.Find("Cursor").gameObject.SetActive(false);
                        }
                        SceneMode = SceneType.SELECT;
                        break;
                    } else {
                        int enemy_id = ClickEnemy(mousePos);
                        if (enemy_id >= 0) {
                            if (enemy_id != select_monster) {
                                Debug.Log("Error: click place is different from cursor place!");
                            }
                            // 遷移処理
                            command_blocks[0].SetActive(false);
                            for (int i = 0; i < num_monster; i++) {
                                enemy_images[i].transform.Find("Cursor").gameObject.SetActive(false);
                            }

                            // 行動順序とそれぞれの行動を決定
                            action_order = SetActionOrder();
                            actions = SetActions(enemy_id);
                            scene_step = 0;
                            action_step = 0;
                            SceneMode = SceneType.PROCESS;
                            Debug.Log(turn_wait_time);
                            break;
                        }
                    }
                }
                FocusEnemy(mousePos);
                break;
            case SceneType.PROCESS:
                if (!(turn_wait_time > 0))  {
                    switch (scene_step) {
                        // 行動者宣言
                        case 0: 
                            scene_step++;
                            Debug.Log(action_order[action_step]);
                            Debug.Log(actions[action_order[action_step]]);
                            turn_wait_time = 1.0f;
                            break;
                        // アクション後処理
                        case 1:
                            scene_step++;
                            Debug.Log("モンスターに5ダメージ");
                            actions[action_order[action_step]].HandleAction();
                            turn_wait_time = 1.0f;
                            break;
                        case 2:
                            scene_step = 0;
                            action_step++;
                            if (action_step >= num_monster + 1) {
                                Debug.Log("ターン処理終了");
                                for (int i = 0; i < 4; i++) {
                                    command_blocks[i].SetActive(true);
                                }
                                SceneMode = SceneType.SELECT;
                            }
                            break;
                    }
                }
                break;
            default:
                break;
        }
    }
}
