using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAction : Action
{
    public EnemyAction(int attacker, int defender, int action_id) : base(attacker, defender, action_id){}

    public void HandleAction(MonsterData.Param pMonster_param) {
        pMonster_param.hp -= 5;
    }
}
