using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Action
{
    public int attacker;
    public int defender;
    public int action_id;

    public Action(int _attacker, int _defender, int _action_id) {
        attacker = _attacker;
        defender = _defender;
        action_id = _action_id;
    }

    public void HandleAction() {
    }
}
